import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { invokeLLM } from "./_core/llm";
import { appRouter } from "./routers";

vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));

const makeContext = (authenticated: boolean): TrpcContext => {
  const user = authenticated
    ? {
        id: 7,
        openId: "hodu-test-user",
        email: "hodu@example.com",
        name: "Hodu Tester",
        loginMethod: "manus",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      }
    : null;

  return {
    user,
    req: { protocol: "https", headers: {} },
    res: {},
  } as unknown as TrpcContext;
};

describe("ai.chat", () => {
  beforeEach(() => vi.clearAllMocks());

  it("sends bounded conversation history to HODU's model and returns its reply", async () => {
    vi.mocked(invokeLLM).mockResolvedValue({
      id: "test-response",
      created: 0,
      model: "claude-haiku-4-5",
      choices: [
        {
          index: 0,
          message: { role: "assistant", content: "우선순위부터 함께 정리해 볼게요." },
          finish_reason: "stop",
        },
      ],
    });

    const caller = appRouter.createCaller(makeContext(true));
    const reply = await caller.ai.chat({
      messages: [{ role: "user", content: "오늘 할 일이 많아." }],
    });

    expect(reply).toBe("우선순위부터 함께 정리해 볼게요.");
    expect(invokeLLM).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "claude-haiku-4-5",
        maxTokens: 1000,
        messages: expect.arrayContaining([
          expect.objectContaining({
            role: "system",
            content: expect.stringContaining("HODU AI"),
          }),
          { role: "user", content: "오늘 할 일이 많아." },
        ]),
      })
    );
  });

  it("requires authentication before invoking the model", async () => {
    const caller = appRouter.createCaller(makeContext(false));

    await expect(
      caller.ai.chat({ messages: [{ role: "user", content: "안녕" }] })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(invokeLLM).not.toHaveBeenCalled();
  });

  it("rejects overlong messages before invoking the model", async () => {
    const caller = appRouter.createCaller(makeContext(true));

    await expect(
      caller.ai.chat({ messages: [{ role: "user", content: "호".repeat(4001) }] })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(invokeLLM).not.toHaveBeenCalled();
  });

  it("returns a user-safe error when the model call fails", async () => {
    vi.mocked(invokeLLM).mockRejectedValue(new Error("private upstream details"));
    const caller = appRouter.createCaller(makeContext(true));
    const logError = vi.spyOn(console, "error").mockImplementation(() => undefined);

    try {
      await expect(
        caller.ai.chat({ messages: [{ role: "user", content: "안녕" }] })
      ).rejects.toMatchObject({
        code: "INTERNAL_SERVER_ERROR",
        message: "AI 답변을 가져오지 못했어요. 잠시 후 다시 시도해 주세요.",
      });
      expect(invokeLLM).toHaveBeenCalledOnce();
    } finally {
      logError.mockRestore();
    }
  });
});
