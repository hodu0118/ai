import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const chatMessage = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().trim().min(1).max(4000),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  ai: router({
    chat: protectedProcedure
      .input(z.object({ messages: z.array(chatMessage).min(1).max(12) }))
      .mutation(async ({ input }) => {
        try {
          const result = await invokeLLM({
            model: "claude-haiku-4-5",
            maxTokens: 1000,
            messages: [
              {
                role: "system",
                content: "당신은 HODU AI, 사용자의 하루를 다정하고 실용적으로 정리해 주는 한국어 개인비서입니다. 따뜻하지만 과하게 들뜨지 않는 말투를 사용하세요. 답변은 기본적으로 간결하고, 복잡한 요청은 실행 가능한 작은 단계로 나누세요. 사용자가 계획이나 우선순위를 요청하면 현실적인 선택지를 제안하세요. 이 앱에서 실제 캘린더 등록, 알림 발송, 외부 연락 등은 수행할 수 없으므로 완료했다고 말하지 마세요. 의료·법률·금융처럼 전문 판단이 필요한 질문에는 일반 정보의 한계를 분명히 하세요. 사용자가 제공하지 않은 개인 정보를 추측하지 마세요.",
              },
              ...input.messages,
            ],
          });
          const answer = result.choices[0]?.message?.content;
          if (typeof answer !== "string" || !answer.trim()) {
            throw new Error("Empty assistant response");
          }
          return answer.trim();
        } catch (error) {
          console.error("[HODU AI] Chat request failed:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "AI 답변을 가져오지 못했어요. 잠시 후 다시 시도해 주세요.",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
