import { describe, expect, it } from "vitest";
import { greetingForUser, pageForLocation } from "../client/src/lib/hoduHome";

describe("HODU AI home experience", () => {
  it("opens the chat view on the root route", () => {
    expect(pageForLocation("/")).toBe("chat");
  });

  it("keeps existing task and note routes available", () => {
    expect(pageForLocation("/tasks")).toBe("tasks");
    expect(pageForLocation("/notes")).toBe("notes");
  });

  it("routes the legacy chat URL to the chat view", () => {
    expect(pageForLocation("/chat")).toBe("chat");
  });

  it("greets the signed-in user by name", () => {
    expect(greetingForUser("  윤호두  ")).toBe("안녕하세요, 윤호두님!");
  });

  it("uses a safe greeting when the user has no name", () => {
    expect(greetingForUser(null)).toBe("안녕하세요!");
    expect(greetingForUser("   ")).toBe("안녕하세요!");
  });
});
