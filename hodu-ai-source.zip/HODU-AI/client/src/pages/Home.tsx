import { AIChatBox } from "@/components/AIChatBox";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { greetingForUser, pageForLocation } from "@/lib/hoduHome";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Circle,
  Leaf,
  ListTodo,
  NotebookPen,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

type ChatMessage = { role: "user" | "assistant"; content: string };

type Task = {
  id: string;
  title: string;
  done: boolean;
  category: string;
};

type Note = {
  id: string;
  title: string;
  body: string;
  createdAt: string;
};

const TASKS_KEY = "hodu.tasks.v1";
const NOTES_KEY = "hodu.notes.v1";
const CHAT_KEY = "hodu.chat.v1";

const sampleTasks: Task[] = [
  { id: "sample-1", title: "이번 주 우선순위 정리하기", done: false, category: "집중" },
  { id: "sample-2", title: "점심 뒤에 20분 산책하기", done: false, category: "리듬" },
  { id: "sample-3", title: "읽던 책 10쪽 읽기", done: false, category: "나를 위한 시간" },
];

const sampleNotes: Note[] = [
  {
    id: "sample-note-1",
    title: "작은 아이디어",
    body: "좋은 하루는 거창한 계획보다, 오늘 꼭 하고 싶은 한 가지에서 시작될지도.",
    createdAt: new Date().toISOString(),
  },
];

function readStore<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function makeId() {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export default function Home() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>(() => readStore(TASKS_KEY, sampleTasks));
  const [notes, setNotes] = useState<Note[]>(() => readStore(NOTES_KEY, sampleNotes));
  const [messages, setMessages] = useState<ChatMessage[]>(() => readStore(CHAT_KEY, []));
  const [newTask, setNewTask] = useState("");
  const [noteTitle, setNoteTitle] = useState("");
  const [noteBody, setNoteBody] = useState("");
  const [chatError, setChatError] = useState(false);

  useEffect(() => window.localStorage.setItem(TASKS_KEY, JSON.stringify(tasks)), [tasks]);
  useEffect(() => window.localStorage.setItem(NOTES_KEY, JSON.stringify(notes)), [notes]);
  useEffect(() => window.localStorage.setItem(CHAT_KEY, JSON.stringify(messages)), [messages]);

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (reply) => {
      setChatError(false);
      setMessages((current) => [...current, { role: "assistant" as const, content: reply }].slice(-40));
    },
    onError: () => {
      setChatError(true);
      toast.error("답변을 가져오지 못했어요. 잠시 후 다시 시도해 주세요.");
    },
  });

  const doneCount = tasks.filter((task) => task.done).length;
  const currentPage = pageForLocation(location);
  const pageTitle = currentPage === "tasks" ? "내 할 일" : currentPage === "notes" ? "메모" : "AI와 대화";

  const addTask = (event?: React.FormEvent) => {
    event?.preventDefault();
    const title = newTask.trim();
    if (!title) return;
    setTasks((current) => [{ id: makeId(), title, done: false, category: "새 할 일" }, ...current]);
    setNewTask("");
  };

  const toggleTask = (id: string) => {
    setTasks((current) => current.map((task) => task.id === id ? { ...task, done: !task.done } : task));
  };

  const deleteTask = (id: string) => {
    setTasks((current) => current.filter((task) => task.id !== id));
  };

  const addNote = (event: React.FormEvent) => {
    event.preventDefault();
    const body = noteBody.trim();
    if (!body) return;
    const title = noteTitle.trim() || body.split("\n")[0].slice(0, 28) || "새 메모";
    setNotes((current) => [{ id: makeId(), title, body, createdAt: new Date().toISOString() }, ...current]);
    setNoteTitle("");
    setNoteBody("");
    toast.success("메모를 저장했어요.");
  };

  const deleteNote = (id: string) => {
    setNotes((current) => current.filter((note) => note.id !== id));
    toast.success("메모를 삭제했어요.");
  };

  const sendMessage = (content: string) => {
    const next = [...messages, { role: "user" as const, content }].slice(-12);
    setMessages(next);
    setChatError(false);
    chatMutation.mutate({ messages: next });
  };

  return (
    <DashboardLayout>
      <div className="hodu-shell">
        <header className="page-header">
          <div>
            <h1>{pageTitle}</h1>
          </div>
          <div className="header-note"><Sparkles size={15} /> 당신의 페이스로, 충분해요</div>
        </header>

        {currentPage === "tasks" && (
          <main className="wide-content animate-in">
            <section className="page-intro-card task-intro">
              <div className="intro-icon"><ListTodo size={20} /></div>
              <div><h2>할 일은 작게, 마음은 가볍게.</h2><p>하나씩 체크하면 오늘의 흐름이 보여요.</p></div>
              <div className="progress-pill"><Check size={15} /> {doneCount} / {tasks.length} 완료</div>
            </section>
            <section className="content-card full-card">
              <div className="card-heading"><div><div className="section-label">YOUR PACE, YOUR PLAN</div><h3>할 일 목록 <span className="count-badge">{tasks.length}</span></h3></div></div>
              <form onSubmit={addTask} className="task-add-form">
                <Plus size={17} />
                <Input aria-label="새 할 일" value={newTask} onChange={(event) => setNewTask(event.target.value)} placeholder="예: 10분 스트레칭하기" />
                <Button type="submit" disabled={!newTask.trim()}>추가하기</Button>
              </form>
              <TaskList tasks={tasks} onToggle={toggleTask} onDelete={deleteTask} />
              {tasks.length === 0 && <EmptyState icon={<CheckCircle2 size={22} />} title="아직 등록된 할 일이 없어요" body="오늘 하고 싶은 작은 일부터 적어볼까요?" />}
              <p className="storage-hint"><Leaf size={13} /> 이 할 일 목록은 현재 사용 중인 브라우저에 저장돼요.</p>
            </section>
          </main>
        )}

        {currentPage === "notes" && (
          <main className="notes-layout animate-in">
            <section className="content-card note-composer">
              <div className="section-label">A LITTLE SPACE FOR YOUR THOUGHTS</div>
              <h2>생각을 편하게 내려놓아요.</h2>
              <p className="composer-subtitle">정리되지 않은 문장도 괜찮아요. 호두가 여기 잘 보관해둘게요.</p>
              <form onSubmit={addNote} className="note-form">
                <Input aria-label="메모 제목" value={noteTitle} onChange={(event) => setNoteTitle(event.target.value)} placeholder="제목 (선택)" />
                <Textarea aria-label="메모 내용" value={noteBody} onChange={(event) => setNoteBody(event.target.value)} placeholder="떠오른 생각을 적어보세요..." rows={5} />
                <div className="note-form-footer"><span>비공개 · 이 브라우저에 저장</span><Button type="submit" disabled={!noteBody.trim()}><Plus size={16} /> 메모 저장</Button></div>
              </form>
            </section>
            <section className="content-card notes-list-card">
              <div className="card-heading"><div><div className="section-label">YOUR NOTEBOOK</div><h3>모아둔 생각 <span className="count-badge">{notes.length}</span></h3></div></div>
              {notes.length ? (
                <div className="notes-list">
                  {notes.map((note) => (
                    <article className="saved-note" key={note.id}>
                      <div className="saved-note-top"><span className="note-mark"><NotebookPen size={16} /></span><time>{new Date(note.createdAt).toLocaleDateString("ko-KR", { month: "long", day: "numeric" })}</time><button onClick={() => deleteNote(note.id)} aria-label={`${note.title} 메모 삭제`} className="icon-button"><Trash2 size={15} /></button></div>
                      <h4>{note.title}</h4><p>{note.body}</p>
                    </article>
                  ))}
                </div>
              ) : <EmptyState icon={<NotebookPen size={22} />} title="첫 메모를 기다리고 있어요" body="떠오른 아이디어나 기억할 일을 남겨보세요." />}
            </section>
          </main>
        )}

        {currentPage === "chat" && (
          <main className="chat-layout animate-in">
            <section className="chat-intro">
              <div className="chat-avatar"><Sparkles size={19} /></div>
              <div><div className="section-label">YOUR THOUGHTFUL AI COMPANION</div><h2>{greetingForUser(user?.name)}</h2><p>호두예요. 오늘 무엇을 도와드릴까요? 편하게 말을 걸어주세요.</p></div>
            </section>
            <div className="chat-box-wrap">
              <AIChatBox
                messages={messages}
                onSendMessage={sendMessage}
                isLoading={chatMutation.isPending}
                height="min(62vh, 590px)"
                emptyStateMessage="오늘의 계획부터 마음속 고민까지, 무엇이든 물어보세요."
                placeholder="호두에게 편하게 이야기해 보세요..."
                suggestedPrompts={["오늘 할 일을 우선순위로 정리해줘", "머릿속이 복잡해. 생각을 같이 정리해줄래?", "기분 전환할 짧은 루틴을 추천해줘"]}
              />
            </div>
            <p className="privacy-note"><Sparkles size={13} /> 대화는 이 브라우저에 저장되고, AI 답변을 위해 대화 내용만 전송돼요. 할 일과 메모는 자동으로 공유되지 않아요.</p>
            {chatError && <button type="button" className="chat-retry-note" onClick={() => { if (messages[messages.length - 1]?.role !== "user") return; setChatError(false); chatMutation.mutate({ messages }); }}><Circle size={12} /> 마지막 질문 다시 보내기 <ArrowRight size={13} /></button>}
          </main>
        )}

        <footer className="page-footer"><span>HODU AI</span><span>당신의 일상에 여백을 더하는 개인비서</span></footer>
      </div>
    </DashboardLayout>
  );
}

function TaskList({ tasks, onToggle, onDelete, compact = false }: { tasks: Task[]; onToggle: (id: string) => void; onDelete: (id: string) => void; compact?: boolean }) {
  if (tasks.length === 0) return <EmptyState icon={<CheckCircle2 size={21} />} title="아직 할 일이 없어요" body="작은 할 일 하나부터 적어볼까요?" />;
  return (
    <div className={`task-list ${compact ? "compact" : ""}`}>
      {tasks.map((task) => (
        <div className={`task-row ${task.done ? "is-done" : ""}`} key={task.id}>
          <Checkbox checked={task.done} onCheckedChange={() => onToggle(task.id)} aria-label={`${task.title} ${task.done ? "미완료로" : "완료로"} 표시`} />
          <span className="task-title">{task.title}</span>
          <Badge variant="secondary" className="task-category">{task.category}</Badge>
          {!compact && <button onClick={() => onDelete(task.id)} className="icon-button task-delete" aria-label={`${task.title} 삭제`}><Trash2 size={15} /></button>}
        </div>
      ))}
    </div>
  );
}

function EmptyState({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return <div className="empty-state"><span className="empty-icon">{icon}</span><strong>{title}</strong><p>{body}</p></div>;
}
