import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { CheckSquare, LayoutDashboard, LogOut, MessageCircle, NotebookPen, PanelLeft } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

const menuItems = [
  { icon: MessageCircle, label: "AI와 대화", path: "/" },
  { icon: CheckSquare, label: "내 할 일", path: "/tasks" },
  { icon: NotebookPen, label: "메모", path: "/notes" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 264;
const MIN_WIDTH = 220;
const MAX_WIDTH = 400;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    try {
      const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
      return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
    } catch {
      return DEFAULT_WIDTH;
    }
  });
  const { loading, user } = useAuth();

  useEffect(() => {
    try { localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString()); } catch { /* storage is optional */ }
  }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;

  if (!user) {
    return (
      <div className="signin-screen">
        <div className="signin-card">
          <div className="hodu-brand large"><span className="hodu-mark"><i /><b /></span><span>HODU<span className="brand-ai">AI</span></span></div>
          <div className="signin-orb"><div className="signin-orb-inner"><span>ㅎ</span><SparkleDot /></div></div>
          <span className="section-label">A LITTLE SPACE FOR YOUR DAY</span>
          <h1>나만의 하루,<br />호두와 함께 정리해요.</h1>
          <p>로그인하면 개인비서를 시작할 수 있어요.<br />할 일과 메모는 현재 사용 중인 브라우저에 저장됩니다.</p>
          <Button onClick={() => startLogin()} size="lg" className="signin-button">HODU AI 시작하기 <PanelLeft size={16} /></Button>
          <small className="signin-footnote">차분하게, 하나씩. 당신의 페이스로.</small>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent>
    </SidebarProvider>
  );
}

function SparkleDot() {
  return <span className="signin-sparkle" aria-hidden="true">✦</span>;
}

type DashboardLayoutContentProps = { children: React.ReactNode; setSidebarWidth: (width: number) => void };

function DashboardLayoutContent({ children, setSidebarWidth }: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = menuItems.find((item) => item.path === location);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = event.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r-0" disableTransition={isResizing}>
          <SidebarHeader className="hodu-sidebar-header">
            <div className="sidebar-brand-row">
              <button onClick={toggleSidebar} className="sidebar-toggle" aria-label="사이드바 접기"><PanelLeft size={17} /></button>
              {!isCollapsed && <div className="hodu-brand"><span className="hodu-mark"><i /><b /></span><span>HODU<span className="brand-ai">AI</span></span></div>}
            </div>
            {!isCollapsed && <div className="sidebar-tagline">당신의 하루에 여백을</div>}
          </SidebarHeader>
          <SidebarContent className="gap-0">
            {!isCollapsed && <div className="sidebar-section-label">WORKSPACE</div>}
            <SidebarMenu className="sidebar-menu-list">
              {menuItems.map((item) => {
                const isActive = location === item.path;
                return (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton isActive={isActive} onClick={() => setLocation(item.path)} tooltip={item.label} className="hodu-menu-button">
                      <item.icon className="size-[17px]" />
                      <span>{item.label}</span>
                      {item.path === "/chat" && !isCollapsed && <span className="menu-spark">✦</span>}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
            {!isCollapsed && <div className="sidebar-note"><span className="sidebar-note-icon">✦</span><strong>천천히 해도 괜찮아요</strong><small>오늘 할 수 있는 만큼이면 충분해요.</small></div>}
          </SidebarContent>
          <SidebarFooter className="sidebar-footer">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="profile-button" aria-label="계정 메뉴">
                  <Avatar className="profile-avatar"><AvatarFallback>{user?.name?.charAt(0)?.toUpperCase() || "H"}</AvatarFallback></Avatar>
                  {!isCollapsed && <div className="profile-meta"><p>{user?.name || "나의 계정"}</p><span>{user?.email || "HODU AI 개인비서"}</span></div>}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="mr-2 size-4" /><span>로그아웃</span></DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {!isCollapsed && <div className="local-save-label"><span /> 이 브라우저에 저장 중</div>}
          </SidebarFooter>
        </Sidebar>
        <div className={`sidebar-resize-handle ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => { if (!isCollapsed) setIsResizing(true); }} />
      </div>
      <SidebarInset>
        {isMobile && <div className="mobile-topbar"><div className="flex items-center gap-2"><SidebarTrigger className="mobile-sidebar-trigger" /><span>{activeMenuItem?.label ?? "오늘"}</span></div><div className="hodu-brand mobile-brand"><span className="hodu-mark"><i /><b /></span><span>HODU<span className="brand-ai">AI</span></span></div></div>}
        <main className="dashboard-main">{children}</main>
      </SidebarInset>
    </>
  );
}
