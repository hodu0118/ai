export type HoduPage = "chat" | "tasks" | "notes";

export function pageForLocation(pathname: string): HoduPage {
  if (pathname === "/tasks") return "tasks";
  if (pathname === "/notes") return "notes";
  return "chat";
}

export function greetingForUser(name?: string | null): string {
  const displayName = name?.trim();
  return displayName ? `안녕하세요, ${displayName}님!` : "안녕하세요!";
}
