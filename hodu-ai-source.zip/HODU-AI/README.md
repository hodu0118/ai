# HODU AI

HODU AI personal-assistant website source. The landing page opens the AI chat and greets the signed-in user by name. Task and note pages remain available in the sidebar.

## Requirements
- Node.js 22
- pnpm 10

## Run locally
1. Install dependencies: `pnpm install --frozen-lockfile`
2. Copy `.env.example` to `.env` and fill in credentials for your own Manus/WebDev environment.
3. Start the development server: `pnpm dev`

Checks: `pnpm check`, `pnpm test`, `pnpm build`.

The ZIP intentionally excludes real credentials, `.project-config.json`, Git history, `node_modules`, and generated build output.
